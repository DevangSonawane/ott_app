import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import 'shimmer_placeholder.dart';

class AppImage extends StatelessWidget {
  const AppImage({
    super.key,
    required this.source,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.borderRadius,
    this.placeholderBorderRadius = 12,
  });

  final String source;
  final double? width;
  final double? height;
  final BoxFit fit;
  final BorderRadius? borderRadius;
  final double placeholderBorderRadius;

  bool get _isAsset => source.startsWith('assets/');
  bool get _isNetwork => source.startsWith('http://') || source.startsWith('https://');

  @override
  Widget build(BuildContext context) {
    Widget child;

    if (source.isEmpty) {
      child = Container(
        width: width,
        height: height,
        color: AppColors.card,
        alignment: Alignment.center,
        child: const Icon(Icons.broken_image_rounded, color: AppColors.textMuted),
      );
    } else if (_isAsset) {
      child = Image.asset(
        source,
        width: width,
        height: height,
        fit: fit,
        errorBuilder: (context, error, stack) => Container(
          width: width,
          height: height,
          color: AppColors.card,
          alignment: Alignment.center,
          child: const Icon(Icons.broken_image_rounded, color: AppColors.textMuted),
        ),
      );
    } else if (_isNetwork) {
      child = CachedNetworkImage(
        imageUrl: source,
        width: width,
        height: height,
        fit: fit,
        placeholder: (context, _) => ShimmerPlaceholder(
          width: width ?? MediaQuery.of(context).size.width,
          height: height ?? (MediaQuery.of(context).size.width * 9 / 16),
          borderRadius: placeholderBorderRadius,
        ),
        errorWidget: (context, _, __) => Container(
          width: width,
          height: height,
          color: AppColors.card,
          alignment: Alignment.center,
          child: const Icon(Icons.broken_image_rounded, color: AppColors.textMuted),
        ),
      );
    } else {
      // Treat any non-http string as an asset-like path fallback.
      child = Image.asset(
        source,
        width: width,
        height: height,
        fit: fit,
        errorBuilder: (context, error, stack) => Container(
          width: width,
          height: height,
          color: AppColors.card,
          alignment: Alignment.center,
          child: const Icon(Icons.broken_image_rounded, color: AppColors.textMuted),
        ),
      );
    }

    final br = borderRadius;
    if (br == null) return child;
    return ClipRRect(borderRadius: br, child: child);
  }
}

