import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/hero_slide.dart';
import '../models/movie.dart';
import '../services/tmdb_service.dart';

const fallbackHeroSlide = HeroSlide(
  id: 'fallback-1',
  title: 'StreamFlix Originals',
  meta: 'Trending now',
  description: 'Premium content, now streaming.',
  image: '',
);

// TMDB genre IDs (subset)
const _kAction = 28;
const _kDrama = 18;
const _kRomance = 10749;
const _kScifi = 878;
const _kThriller = 53;
const _kHorror = 27;
const _kComedy = 35;

final heroSlidesProvider = FutureProvider<List<HeroSlide>>((ref) async {
  final slides = await TmdbService.fetchHeroSlides();
  return slides.isEmpty ? const [fallbackHeroSlide] : slides;
});

final continueWatchingProvider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchNowPlaying();
});

final bollywoodProvider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchBollywood();
});

final indianSeriesProvider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchIndianSeries();
});

final hollywoodProvider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchTrending(type: 'movie');
});

final trendingTvProvider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchTrending(type: 'tv');
});

final top10Provider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchTopRated(type: 'movie', region: 'IN');
});

final dramaProvider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchByGenre(_kDrama, type: 'tv');
});

final actionProvider = FutureProvider<List<Movie>>((ref) async {
  return TmdbService.fetchByGenre(_kAction);
});

final genreContentProvider =
    FutureProvider.family<List<Movie>, String>((ref, genreId) async {
  switch (genreId) {
    case 'action':
      return TmdbService.fetchByGenre(_kAction);
    case 'drama':
      return TmdbService.fetchByGenre(_kDrama, type: 'tv');
    case 'romance':
      return TmdbService.fetchByGenre(_kRomance);
    case 'scifi':
      return TmdbService.fetchByGenre(_kScifi);
    case 'thriller':
      return TmdbService.fetchByGenre(_kThriller);
    case 'horror':
      return TmdbService.fetchByGenre(_kHorror);
    case 'comedy':
      return TmdbService.fetchByGenre(_kComedy);
    default:
      return TmdbService.fetchTrending();
  }
});

final searchQueryProvider = StateProvider<String>((ref) => '');

final searchResultsProvider = FutureProvider<List<Movie>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  if (query.trim().isEmpty) return TmdbService.fetchTrending();
  return TmdbService.search(query);
});

final allTmdbContentProvider = FutureProvider<List<Movie>>((ref) async {
  final results = await Future.wait([
    TmdbService.fetchTrending(type: 'movie'),
    TmdbService.fetchTrending(type: 'tv'),
    TmdbService.fetchBollywood(),
  ]);
  final seen = <String>{};
  return results.expand((l) => l).where((m) => seen.add(m.id)).toList(growable: false);
});

