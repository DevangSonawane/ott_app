import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/hero_slide.dart';
import '../models/movie.dart';
import '../services/tmdb_service.dart';
import '../services/web_content_repository.dart';

enum ContentSource { tmdb, web }

final contentSourceProvider = Provider<ContentSource>((ref) {
  final raw = (dotenv.env['CONTENT_SOURCE'] ?? '').trim().toLowerCase();
  final hasTmdbKey = (dotenv.env['TMDB_API_KEY'] ?? '').trim().isNotEmpty;

  if (raw == 'web' || raw == 'react' || raw == 'react-web') {
    return ContentSource.web;
  }
  if (raw == 'tmdb') {
    return hasTmdbKey ? ContentSource.tmdb : ContentSource.web;
  }
  // Default: use TMDB only if configured, otherwise fall back to web assets.
  return hasTmdbKey ? ContentSource.tmdb : ContentSource.web;
});

const fallbackHeroSlide = HeroSlide(
  id: 'fallback-1',
  title: 'StreamFlix Originals',
  meta: 'Trending now',
  description: 'Premium content, now streaming.',
  image: '',
);

final heroSlidesProvider = FutureProvider<List<HeroSlide>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      final web = await WebContentRepository.load();
      return web.heroSlides.isEmpty ? const [fallbackHeroSlide] : web.heroSlides;
    case ContentSource.tmdb:
      final slides = await TmdbService.fetchHeroSlides();
      return slides.isEmpty ? const [fallbackHeroSlide] : slides;
  }
});

final continueWatchingProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      return (await WebContentRepository.load()).continueWatching;
    case ContentSource.tmdb:
      return TmdbService.fetchNowPlaying();
  }
});

final bollywoodProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      return (await WebContentRepository.load()).topBollywood;
    case ContentSource.tmdb:
      return TmdbService.fetchBollywood();
  }
});

final indianSeriesProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      return (await WebContentRepository.load()).indianWebSeries;
    case ContentSource.tmdb:
      return TmdbService.fetchIndianSeries();
  }
});

final hollywoodProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      return (await WebContentRepository.load()).topHollywood;
    case ContentSource.tmdb:
      return TmdbService.fetchTrending(type: 'movie');
  }
});

final trendingTvProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      final web = await WebContentRepository.load();
      return web.trendingNow.where((m) => m.type == 'series').toList(growable: false);
    case ContentSource.tmdb:
      return TmdbService.fetchTrending(type: 'tv');
  }
});

final top10Provider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      return (await WebContentRepository.load()).top10;
    case ContentSource.tmdb:
      return TmdbService.fetchTopRated(type: 'movie', region: 'IN');
  }
});

final dramaProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      final web = await WebContentRepository.load();
      return web.genreContent['drama'] ?? const <Movie>[];
    case ContentSource.tmdb:
      return TmdbService.fetchByGenre(18, type: 'tv');
  }
});

final actionProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      final web = await WebContentRepository.load();
      return web.genreContent['action'] ?? const <Movie>[];
    case ContentSource.tmdb:
      return TmdbService.fetchByGenre(28);
  }
});

final genreContentProvider =
    FutureProvider.family<List<Movie>, String>((ref, genreId) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      final web = await WebContentRepository.load();
      return web.genreContent[genreId] ?? web.trendingNow;
    case ContentSource.tmdb:
      // Match the genre IDs used earlier.
      switch (genreId) {
        case 'action':
          return TmdbService.fetchByGenre(28);
        case 'drama':
          return TmdbService.fetchByGenre(18, type: 'tv');
        case 'romance':
          return TmdbService.fetchByGenre(10749);
        case 'scifi':
          return TmdbService.fetchByGenre(878);
        case 'thriller':
          return TmdbService.fetchByGenre(53);
        case 'horror':
          return TmdbService.fetchByGenre(27);
        case 'comedy':
          return TmdbService.fetchByGenre(35);
        default:
          return TmdbService.fetchTrending();
      }
  }
});

final searchQueryProvider = StateProvider<String>((ref) => '');

final searchResultsProvider = FutureProvider<List<Movie>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  final source = ref.watch(contentSourceProvider);

  if (query.trim().isEmpty) {
    switch (source) {
      case ContentSource.web:
        return (await WebContentRepository.load()).trendingNow;
      case ContentSource.tmdb:
        return TmdbService.fetchTrending();
    }
  }

  switch (source) {
    case ContentSource.web:
      final web = await WebContentRepository.load();
      final q = query.trim().toLowerCase();
      return web.allMovies
          .where((m) =>
              m.title.toLowerCase().contains(q) ||
              m.genre.any((g) => g.toLowerCase().contains(q)))
          .toList(growable: false);
    case ContentSource.tmdb:
      return TmdbService.search(query);
  }
});

final allContentProvider = FutureProvider<List<Movie>>((ref) async {
  final source = ref.watch(contentSourceProvider);
  switch (source) {
    case ContentSource.web:
      return (await WebContentRepository.load()).allMovies;
    case ContentSource.tmdb:
      final results = await Future.wait([
        TmdbService.fetchTrending(type: 'movie'),
        TmdbService.fetchTrending(type: 'tv'),
        TmdbService.fetchBollywood(),
      ]);
      final seen = <String>{};
      return results
          .expand((l) => l)
          .where((m) => seen.add(m.id))
          .toList(growable: false);
  }
});
