import 'dart:convert';

import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

import '../models/hero_slide.dart';
import '../models/movie.dart';

class TmdbService {
  static String get _apiKey => dotenv.env['TMDB_API_KEY'] ?? '';
  static String get _base => dotenv.env['TMDB_BASE_URL'] ?? 'https://api.themoviedb.org/3';
  static String get _img => dotenv.env['TMDB_IMAGE_BASE'] ?? 'https://image.tmdb.org/t/p';

  static bool get _useBearer => _apiKey.contains('.') && _apiKey.length > 40;

  static Map<String, String> get _headers => _useBearer && _apiKey.isNotEmpty
      ? {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        }
      : const {
          'Content-Type': 'application/json',
        };

  static Uri _uri(String path, [Map<String, String>? query]) {
    final q = <String, String>{...?query};
    if (!_useBearer && _apiKey.isNotEmpty) q['api_key'] = _apiKey;
    return Uri.parse('$_base$path').replace(queryParameters: q);
  }

  // Image URL helpers (return empty for missing paths; UI renders a fallback)
  static String poster(String? path, {String size = 'w500'}) {
    if (path == null || path.isEmpty) return '';
    return '$_img/$size$path';
  }

  static String backdrop(String? path, {String size = 'w1280'}) {
    if (path == null || path.isEmpty) return '';
    return '$_img/$size$path';
  }

  // Convert genre IDs to genre name strings (kept small and stable)
  static final _genreMap = <int, String>{
    28: 'Action',
    12: 'Adventure',
    16: 'Animation',
    35: 'Comedy',
    80: 'Crime',
    99: 'Documentary',
    18: 'Drama',
    10751: 'Family',
    14: 'Fantasy',
    36: 'History',
    27: 'Horror',
    10402: 'Music',
    9648: 'Mystery',
    10749: 'Romance',
    878: 'Sci-Fi',
    10770: 'TV Movie',
    53: 'Thriller',
    10752: 'War',
    37: 'Western',
    // TV genres
    10759: 'Action',
    10762: 'Kids',
    10763: 'News',
    10764: 'Reality',
    10765: 'Sci-Fi',
    10766: 'Soap',
    10767: 'Talk',
    10768: 'War',
  };

  static List<String> _genres(List<dynamic> ids) {
    return ids
        .cast<int>()
        .map((id) => _genreMap[id] ?? 'Drama')
        .take(3)
        .toList(growable: false);
  }

  static Movie _movieFromJson(Map<String, dynamic> j) {
    final isMovie = (j['media_type'] == 'movie') || j.containsKey('release_date');
    return Movie(
      id: j['id'].toString(),
      title: (j['title'] ?? j['name'] ?? 'Unknown') as String,
      year: int.tryParse(
              ((j['release_date'] ?? j['first_air_date'] ?? '2020') as String)
                  .split('-')
                  .first) ??
          2020,
      genre: _genres((j['genre_ids'] as List<dynamic>?) ?? const []),
      type: isMovie ? 'movie' : 'series',
      description: (j['overview'] ?? '') as String,
      image: poster(j['poster_path'] as String?),
      rating: ((j['vote_average'] as num?) ?? 0) / 10,
      duration: isMovie ? '2h 0m' : null,
    );
  }

  static Future<List<HeroSlide>> fetchHeroSlides() async {
    try {
      final res = await http.get(
        _uri('/trending/all/week', {'language': 'en-US', 'page': '1'}),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <HeroSlide>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final results = (data['results'] as List<dynamic>).take(5).toList();
      return results.map<HeroSlide>((raw) {
        final j = raw as Map<String, dynamic>;
        final genreNames = _genres((j['genre_ids'] as List<dynamic>?) ?? const []);
        final year = ((j['release_date'] ?? j['first_air_date'] ?? '2020') as String)
            .split('-')
            .first;
        return HeroSlide(
          id: j['id'].toString(),
          title: (j['title'] ?? j['name'] ?? '') as String,
          meta: '$year | ${genreNames.join(' | ')}',
          description: (j['overview'] ?? '') as String,
          image: backdrop(j['backdrop_path'] as String?),
        );
      }).toList(growable: false);
    } catch (_) {
      return const <HeroSlide>[];
    }
  }

  static Future<List<Movie>> fetchTrending({String type = 'movie'}) async {
    try {
      final res = await http.get(
        _uri('/trending/$type/week', {'language': 'en-US'}),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <Movie>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['results'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map(_movieFromJson)
          .toList(growable: false);
    } catch (_) {
      return const <Movie>[];
    }
  }

  static Future<List<Movie>> fetchTopRated({String type = 'movie', String region = 'IN'}) async {
    try {
      final res = await http.get(
        _uri('/$type/top_rated', {'language': 'en-US', 'region': region, 'page': '1'}),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <Movie>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['results'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map(_movieFromJson)
          .take(10)
          .toList(growable: false);
    } catch (_) {
      return const <Movie>[];
    }
  }

  static Future<List<Movie>> fetchByGenre(int genreId, {String type = 'movie'}) async {
    try {
      final res = await http.get(
        _uri('/discover/$type', {
          'with_genres': genreId.toString(),
          'language': 'en-US',
          'sort_by': 'popularity.desc',
          'page': '1',
        }),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <Movie>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['results'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map(_movieFromJson)
          .toList(growable: false);
    } catch (_) {
      return const <Movie>[];
    }
  }

  static Future<List<Movie>> fetchBollywood() async {
    try {
      final res = await http.get(
        _uri('/discover/movie', {
          'with_original_language': 'hi',
          'region': 'IN',
          'sort_by': 'popularity.desc',
          'page': '1',
        }),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <Movie>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['results'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map(_movieFromJson)
          .toList(growable: false);
    } catch (_) {
      return const <Movie>[];
    }
  }

  static Future<List<Movie>> fetchIndianSeries() async {
    try {
      final res = await http.get(
        _uri('/discover/tv', {
          'with_original_language': 'hi',
          'sort_by': 'popularity.desc',
          'page': '1',
        }),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <Movie>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['results'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map(_movieFromJson)
          .toList(growable: false);
    } catch (_) {
      return const <Movie>[];
    }
  }

  static Future<List<Movie>> fetchNowPlaying({String region = 'IN'}) async {
    try {
      final res = await http.get(
        _uri('/movie/now_playing', {'language': 'en-US', 'region': region, 'page': '1'}),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <Movie>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['results'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map((j) {
            final m = _movieFromJson(j);
            final progress = 20 + (m.id.hashCode.abs() % 70);
            return m.copyWith(progress: progress);
          })
          .take(8)
          .toList(growable: false);
    } catch (_) {
      return const <Movie>[];
    }
  }

  static Future<List<Movie>> search(String query) async {
    if (query.trim().isEmpty) return const <Movie>[];
    try {
      final res = await http.get(
        _uri('/search/multi', {
          'query': query,
          'language': 'en-US',
          'page': '1',
          'include_adult': 'false',
        }),
        headers: _headers,
      );
      if (res.statusCode != 200) return const <Movie>[];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['results'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .where((j) => j['media_type'] == 'movie' || j['media_type'] == 'tv')
          .map(_movieFromJson)
          .toList(growable: false);
    } catch (_) {
      return const <Movie>[];
    }
  }
}

