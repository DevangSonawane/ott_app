import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env');
  debugPrint(
    "ENV loaded: CONTENT_SOURCE='${dotenv.env['CONTENT_SOURCE']}', TMDB_API_KEY set=${(dotenv.env['TMDB_API_KEY'] ?? '').trim().isNotEmpty}",
  );
  await Hive.initFlutter();
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light);
  runApp(
    const ProviderScope(
      child: StreamFlixApp(),
    ),
  );
}
