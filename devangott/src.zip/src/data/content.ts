import type { Movie, HeroSlide, UserProfile, SubscriptionPlan, Genre } from '@/types';

export const heroSlides: HeroSlide[] = [
  {
    id: '1',
    title: 'Stranger Things',
    meta: '2016 | Sci-Fi | Horror',
    description: 'When a young boy disappears, his mother, a police chief and his friends must confront terrifying supernatural forces in order to get him back.',
    image: '/hero-stranger-things.jpg'
  },
  {
    id: '2',
    title: 'The Witcher',
    meta: '2019 | Fantasy | Action',
    description: 'Geralt of Rivia, a solitary monster hunter, struggles to find his place in a world where people often prove more wicked than beasts.',
    image: '/hero-witcher.jpg'
  },
  {
    id: '3',
    title: 'Money Heist',
    meta: '2017 | Crime | Thriller',
    description: 'An unusual group of robbers attempt to carry out the most perfect robbery in Spanish history - stealing 2.4 billion euros from the Royal Mint of Spain.',
    image: '/hero-money-heist.jpg'
  }
];

export const continueWatching: Movie[] = [
  {
    id: 'cw1',
    title: 'Friends',
    year: 1994,
    genre: ['Comedy', 'Romance'],
    type: 'series',
    description: 'Six friends navigate life and love in New York City.',
    image: '/Continue Watching/Friends.png',
    progress: 62,
    episodeInfo: { season: 5, episode: 8, episodeTitle: 'The One with the Thanksgiving Flashbacks' }
  },
  {
    id: 'cw2',
    title: 'Gilmore Girls',
    year: 2000,
    genre: ['Drama', 'Comedy'],
    type: 'series',
    description: 'A fast-talking mother and daughter share an unbreakable bond.',
    image: '/Continue Watching/Gilmore Girls.png',
    progress: 34,
    episodeInfo: { season: 2, episode: 12, episodeTitle: 'Richard in Stars Hollow' }
  },
  {
    id: 'cw3',
    title: 'Jawan',
    year: 2023,
    genre: ['Action', 'Thriller'],
    type: 'series',
    description: 'A high-octane action thriller with a vigilante twist.',
    image: '/Continue Watching/Jawan.png',
    progress: 78,
    episodeInfo: { season: 1, episode: 1, episodeTitle: 'The Mission' }
  },
  {
    id: 'cw4',
    title: 'The Big Bang Theory',
    year: 2007,
    genre: ['Comedy'],
    type: 'series',
    description: 'Two brilliant physicists navigate life and relationships.',
    image: '/Continue Watching/The Big Bang Theory.png',
    progress: 51,
    episodeInfo: { season: 3, episode: 14, episodeTitle: 'The Einstein Approximation' }
  },
  {
    id: 'cw5',
    title: 'The Office',
    year: 2005,
    genre: ['Comedy'],
    type: 'series',
    description: 'A mockumentary on a quirky paper company.',
    image: '/Continue Watching/The Office.png',
    progress: 87,
    episodeInfo: { season: 4, episode: 13, episodeTitle: 'Dinner Party' }
  },
  {
    id: 'cw6',
    title: 'The Vampire Diaries',
    year: 2009,
    genre: ['Drama', 'Fantasy'],
    type: 'series',
    description: 'A supernatural love triangle in Mystic Falls.',
    image: '/Continue Watching/The Vampire Diaries.png',
    progress: 28,
    episodeInfo: { season: 2, episode: 6, episodeTitle: 'Plan B' }
  }
];

export const trendingNow: Movie[] = [
  {
    id: 't1',
    title: 'Dune: Part Two',
    year: 2024,
    genre: ['Sci-Fi', 'Adventure'],
    type: 'movie',
    description: 'Paul Atreides unites with Chani and the Fremen while seeking revenge.',
    image: '/trending-dune.jpg',
    rating: 8.9
  },
  {
    id: 't2',
    title: 'The Last of Us',
    year: 2023,
    genre: ['Drama', 'Horror'],
    type: 'series',
    description: 'Joel and Ellie navigate a post-apocalyptic America.',
    image: '/trending-last-of-us.jpg',
    rating: 8.7
  },
  {
    id: 't3',
    title: 'Oppenheimer',
    year: 2023,
    genre: ['Biography', 'Drama'],
    type: 'movie',
    description: 'The story of American scientist J. Robert Oppenheimer.',
    image: '/trending-oppenheimer.jpg',
    rating: 8.6
  },
  {
    id: 't4',
    title: 'The Bear',
    year: 2022,
    genre: ['Comedy', 'Drama'],
    type: 'series',
    description: 'A young chef returns to Chicago to run his family sandwich shop.',
    image: '/trending-bear.jpg',
    rating: 8.4
  },
  {
    id: 't5',
    title: 'Poor Things',
    year: 2023,
    genre: ['Comedy', 'Romance'],
    type: 'movie',
    description: 'The incredible tale and fantastical evolution of Bella Baxter.',
    image: '/trending-poor-things.jpg',
    rating: 8.0
  },
  {
    id: 't6',
    title: 'Severance',
    year: 2022,
    genre: ['Sci-Fi', 'Drama'],
    type: 'series',
    description: 'Employees at Lumon Industries undergo a severance procedure.',
    image: '/trending-severance.jpg',
    rating: 8.7
  },
  {
    id: 't7',
    title: 'Killers of the Flower Moon',
    year: 2023,
    genre: ['Crime', 'Drama'],
    type: 'movie',
    description: 'Real-life murders of the Osage Native Americans in 1920s Oklahoma.',
    image: '/trending-killers-moon.jpg',
    rating: 7.6
  },
  {
    id: 't8',
    title: 'The White Lotus',
    year: 2021,
    genre: ['Comedy', 'Drama'],
    type: 'series',
    description: 'The vacations of various hotel guests over the span of a week.',
    image: '/trending-white-lotus.jpg',
    rating: 7.9
  }
];

export const top10: Movie[] = [
  { id: 'top1', title: 'Squid Game', year: 2021, genre: ['Thriller', 'Drama'], type: 'series', description: 'Hundreds of cash-strapped players accept a strange invitation.', image: '/top10-squid-game.jpg', rating: 8.0 },
  { id: 'top2', title: 'Wednesday', year: 2022, genre: ['Comedy', 'Fantasy'], type: 'series', description: 'Wednesday Addams investigates a murder spree.', image: '/top10-wednesday.jpg', rating: 8.1 },
  { id: 'top3', title: 'You', year: 2018, genre: ['Crime', 'Drama'], type: 'series', description: 'A dangerously charming man goes to extreme measures.', image: '/top10-you.jpg', rating: 7.7 },
  { id: 'top4', title: 'Bridgerton', year: 2020, genre: ['Romance', 'Drama'], type: 'series', description: 'Wealthy Bridgerton family in Regency era London.', image: '/top10-bridgerton.jpg', rating: 7.4 },
  { id: 'top5', title: 'The Queen\'s Gambit', year: 2020, genre: ['Drama'], type: 'series', description: 'An orphan chess prodigy rises to the top.', image: '/top10-queens-gambit.jpg', rating: 8.5 },
  { id: 'top6', title: 'Don\'t Look Up', year: 2021, genre: ['Comedy', 'Drama'], type: 'movie', description: 'Two astronomers go on a media tour to warn of an asteroid.', image: '/top10-dont-look-up.jpg', rating: 7.2 },
  { id: 'top7', title: 'Red Notice', year: 2021, genre: ['Action', 'Comedy'], type: 'movie', description: 'An Interpol agent tracks the world\'s most wanted art thief.', image: '/top10-red-notice.jpg', rating: 6.3 },
  { id: 'top8', title: 'Bird Box', year: 2018, genre: ['Horror', 'Sci-Fi'], type: 'movie', description: 'Five years after an ominous unseen presence drives society to suicide.', image: '/top10-bird-box.jpg', rating: 6.6 },
  { id: 'top9', title: 'Extraction', year: 2020, genre: ['Action', 'Thriller'], type: 'movie', description: 'A black-market mercenary\'s latest mission becomes deadly.', image: '/top10-extraction.jpg', rating: 6.8 },
  { id: 'top10', title: 'The Irishman', year: 2019, genre: ['Crime', 'Drama'], type: 'movie', description: 'An aging hitman recalls his past.', image: '/top10-irishman.jpg', rating: 7.8 }
];

export const topBollywood: Movie[] = [
  { id: 'bm1', title: 'Dhadak 2', year: 2024, genre: ['Drama'], type: 'movie', description: 'A heartfelt story of love and resilience.', image: '/Top Movies/Dhadak 2.png', rating: 7.2 },
  { id: 'bm2', title: 'Dhurandhar', year: 2024, genre: ['Action', 'Thriller'], type: 'movie', description: 'A high-stakes mission turns personal.', image: '/Top Movies/Dhurandhar.png', rating: 7.8 },
  { id: 'bm3', title: 'Raid 2', year: 2024, genre: ['Crime', 'Thriller'], type: 'movie', description: 'The next chapter in the raid saga.', image: '/Top Movies/Raid 2.png', rating: 7.5 },
  { id: 'bm4', title: 'The Diplomat', year: 2024, genre: ['Drama', 'Thriller'], type: 'movie', description: 'Diplomacy meets danger on the world stage.', image: '/Top Movies/The Diplomat.png', rating: 7.1 },
  { id: 'bm5', title: 'Ae Dil Hai Mushkil', year: 2016, genre: ['Drama', 'Romance'], type: 'movie', description: 'A complicated tale of love and friendship.', image: '/Top Movies/ae dil hai mushkil.png', rating: 7.0 },
  { id: 'bm6', title: 'Deva', year: 2024, genre: ['Action'], type: 'movie', description: 'A rebel rises against the odds.', image: '/Top Movies/deva.png', rating: 7.3 },
  { id: 'bm7', title: 'Haq', year: 2024, genre: ['Drama'], type: 'movie', description: 'A fight for justice and dignity.', image: '/Top Movies/haq.png', rating: 6.9 },
  { id: 'bm8', title: 'Kahaani 2', year: 2016, genre: ['Thriller', 'Mystery'], type: 'movie', description: 'A gripping mystery of a mother and child.', image: '/Top Movies/kahaani 2.png', rating: 7.4 },
  { id: 'bm9', title: 'Padmaavat', year: 2018, genre: ['Drama', 'History'], type: 'movie', description: 'An epic tale of honor and valor.', image: '/Top Movies/padmaavati.png', rating: 7.0 },
  { id: 'bm10', title: 'Son of Sardaar 2', year: 2024, genre: ['Comedy', 'Action'], type: 'movie', description: 'Comedy and chaos return.', image: '/Top Movies/son of sardar 2.png', rating: 6.8 }
];

export const indianWebSeries: Movie[] = [
  { id: 'ws1', title: 'Bhay', year: 2024, genre: ['Thriller'], type: 'series', description: 'A dark mystery unravels.', image: '/Indian Web Series/Bhay.png', rating: 7.6 },
  { id: 'ws2', title: 'Dabba Cartel', year: 2024, genre: ['Crime', 'Drama'], type: 'series', description: 'Tiffins, secrets, and power.', image: '/Indian Web Series/Dabba Cartel.png', rating: 7.8 },
  { id: 'ws3', title: 'Farzi', year: 2023, genre: ['Crime', 'Thriller'], type: 'series', description: 'A con artist enters the big leagues.', image: '/Indian Web Series/Farzi.png', rating: 8.2 },

  { id: 'ws5', title: 'Khufiya', year: 2024, genre: ['Thriller'], type: 'series', description: 'A covert operation in the shadows.', image: '/Indian Web Series/Khufiya.png', rating: 7.5 },
  { id: 'ws6', title: 'Call Me Bae', year: 2024, genre: ['Drama', 'Comedy'], type: 'series', description: 'High society meets chaos.', image: '/Indian Web Series/call me bae.png', rating: 7.1 },
  { id: 'ws7', title: 'Rana Naidu', year: 2023, genre: ['Crime', 'Drama'], type: 'series', description: 'A fixer’s world turns personal.', image: '/Indian Web Series/rana naidu.png', rating: 7.7 },
  { id: 'ws8', title: 'Ziddi Girls', year: 2024, genre: ['Drama'], type: 'series', description: 'A bold new generation.', image: '/Indian Web Series/ziddi girls.png', rating: 7.3 }
];

export const topHollywood: Movie[] = [
  { id: 'th1', title: 'Anaconda', year: 2024, genre: ['Action', 'Thriller'], type: 'movie', description: 'A deadly hunt in the wild.', image: '/Top Hollywood/Anaconda.png', rating: 6.8 },
 
  { id: 'th3', title: 'Anniversary', year: 2024, genre: ['Drama'], type: 'movie', description: 'A celebration turns suspenseful.', image: '/Top Hollywood/Anniversary.png', rating: 7.1 },
  { id: 'th4', title: 'Avatar: Fire and Ice', year: 2025, genre: ['Sci-Fi', 'Adventure'], type: 'movie', description: 'A new era on Pandora.', image: '/Top Hollywood/Avatar Fire and Ice.png', rating: 8.4 },
  { id: 'th5', title: 'Flight Risk', year: 2024, genre: ['Thriller'], type: 'movie', description: 'High altitude danger.', image: '/Top Hollywood/Flight Risk.png', rating: 7.0 },
  { id: 'th6', title: 'Gladiator 2', year: 2024, genre: ['Action', 'Drama'], type: 'movie', description: 'The arena calls again.', image: '/Top Hollywood/Gladiator 2.png', rating: 8.0 },
  { id: 'th7', title: 'Warlord', year: 2024, genre: ['Action', 'War'], type: 'movie', description: 'A war epic unfolds.', image: '/Top Hollywood/Warlord.png', rating: 7.3 },
  { id: 'th8', title: 'Sinners', year: 2024, genre: ['Thriller'], type: 'movie', description: 'Secrets come to light.', image: '/Top Hollywood/sinners.png', rating: 7.2 },
  { id: 'th9', title: 'Cover', year: 2024, genre: ['Drama'], type: 'movie', description: 'A dramatic revelation.', image: '/Top Hollywood/cover.png', rating: 6.9 }
];

export const newReleases: Movie[] = [
  {
    id: 'nr1',
    title: 'Rebel Moon',
    year: 2023,
    genre: ['Sci-Fi', 'Action'],
    type: 'movie',
    description: 'A peaceful colony on the edge of the galaxy is threatened.',
    image: '/new-rebel-moon.jpg',
    rating: 5.6
  },
  { id: 'th3', title: 'Anniversary', year: 2024, genre: ['Drama'], type: 'movie', description: 'A celebration turns suspenseful.', image: '/Top Hollywood/Anniversary.png', rating: 7.1 },
  {
    id: 'nr2',
    title: 'Leave the World Behind',
    year: 2023,
    genre: ['Thriller', 'Drama'],
    type: 'movie',
    description: 'A family\'s vacation is upended by two strangers.',
    image: '/new-leave-world.jpg',
    rating: 6.5
  },
  {
    id: 'nr3',
    title: 'Maestro',
    year: 2023,
    genre: ['Biography', 'Drama'],
    type: 'movie',
    description: 'The complex love story of Leonard and Felicia Bernstein.',
    image: '/new-maestro.jpg',
    rating: 6.8
  },
  {
    id: 'nr4',
    title: 'Saltburn',
    year: 2023,
    genre: ['Thriller', 'Drama'],
    type: 'movie',
    description: 'A student becomes obsessed with a classmate and his family.',
    image: '/new-saltburn.jpg',
    rating: 7.1
  },
  {
    id: 'nr5',
    title: 'May December',
    year: 2023,
    genre: ['Drama'],
    type: 'movie',
    description: 'Twenty years after their notorious tabloid romance.',
    image: '/new-may-december.jpg',
    rating: 6.9
  }
];

export const profiles: UserProfile[] = [
  { id: '1', name: 'Alex', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex' },
  { id: '2', name: 'Sarah', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah' },
  { id: '3', name: 'Kids', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kids', isKids: true },
  { id: '4', name: 'Guest', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Guest' }
];

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'monthly',
    name: 'Monthly',
    price: 199,
    period: 'month',
    features: [
      'Unlimited streaming',
      'Watch on any device',
      'HD + 4K available',
      'Cancel anytime'
    ]
  },
  {
    id: 'quarterly',
    name: '3 Months',
    price: 499,
    period: '3 months',
    features: [
      'Save vs monthly',
      'Unlimited streaming',
      'Offline downloads',
      'Priority support'
    ],
    isPopular: true
  },
  {
    id: 'yearly',
    name: '1 Year',
    price: 1499,
    period: 'year',
    features: [
      'Best value plan',
      'Unlimited streaming',
      '4K + HDR',
      'Family sharing',
      'Offline downloads'
    ]
  }
];

export const genres: Genre[] = [
  { id: 'action', name: 'Action', icon: 'Sword', color: '#a855f7' },
  { id: 'adventure', name: 'Adventure', icon: 'Mountain', color: '#44ff88' },
  { id: 'animation', name: 'Animation', icon: 'Palette', color: '#ffaa44' },
  { id: 'comedy', name: 'Comedy', icon: 'Laugh', color: '#ffdd44' },
  { id: 'crime', name: 'Crime', icon: 'Fingerprint', color: '#aa44ff' },
  { id: 'documentary', name: 'Documentary', icon: 'Camera', color: '#44aaff' },
  { id: 'drama', name: 'Drama', icon: 'Theater', color: '#d946ef' },
  
  { id: 'fantasy', name: 'Fantasy', icon: 'Sparkles', color: '#44ffdd' },
  { id: 'horror', name: 'Horror', icon: 'Ghost', color: '#6d28d9' },
  { id: 'mystery', name: 'Mystery', icon: 'Search', color: '#4444ff' },
  { id: 'romance', name: 'Romance', icon: 'Heart', color: '#ec4899' },
  { id: 'scifi', name: 'Sci-Fi', icon: 'Rocket', color: '#00aaff' },
  { id: 'thriller', name: 'Thriller', icon: 'AlertTriangle', color: '#f59e0b' }
];

export const genreContent: Record<string, Movie[]> = {
  action: [
    { id: 'a1', title: 'Extraction 2', year: 2023, genre: ['Action'], type: 'movie', description: 'Commando Tyler Rake returns for another mission.', image: '/top10-extraction.jpg', rating: 7.0 },
    { id: 'th6', title: 'Gladiator 2', year: 2024, genre: ['Action', 'Drama'], type: 'movie', description: 'The arena calls again.', image: '/Top Hollywood/Gladiator 2.png', rating: 8.0 },
    { id: 'th7', title: 'Warlord', year: 2024, genre: ['Action', 'War'], type: 'movie', description: 'A war epic unfolds.', image: '/Top Hollywood/Warlord.png', rating: 7.3 },
  { id: 'bm2', title: 'Dhurandhar', year: 2024, genre: ['Action', 'Thriller'], type: 'movie', description: 'A high-stakes mission turns personal.', image: '/Top Movies/Dhurandhar.png', rating: 7.8 },
    { id: 'a2', title: 'The Witcher', year: 2019, genre: ['Action', 'Fantasy'], type: 'series', description: 'Monster hunter Geralt of Rivia.', image: '/hero-witcher.jpg', rating: 8.2 },
    { id: 'a3', title: 'Dune: Part Two', year: 2024, genre: ['Action', 'Sci-Fi'], type: 'movie', description: 'Paul Atreides seeks revenge.', image: '/trending-dune.jpg', rating: 8.9 },
    { id: 'a4', title: 'Red Notice', year: 2021, genre: ['Action', 'Comedy'], type: 'movie', description: 'Art thief hunt around the world.', image: '/top10-red-notice.jpg', rating: 6.3 },
  ],
  romance: [
    { id: 'r1', title: 'Bridgerton', year: 2020, genre: ['Romance', 'Drama'], type: 'series', description: 'Regency era London romance.', image: '/top10-bridgerton.jpg', rating: 7.4 },
    { id: 'r2', title: 'The Secret Bloom', year: 2023, genre: ['Romance', 'Drama'], type: 'series', description: 'Two women in a complex relationship.', image: '/new-may-december.jpg', rating: 6.9 },
    { id: 'r3', title: 'Poor Things', year: 2023, genre: ['Romance', 'Comedy'], type: 'movie', description: 'Bella Baxter\'s fantastical journey.', image: '/trending-poor-things.jpg', rating: 8.0 },
  ],
  scifi: [
    { id: 's1', title: 'Stranger Things', year: 2016, genre: ['Sci-Fi', 'Horror'], type: 'series', description: 'Supernatural forces in a small town.', image: '/hero-stranger-things.jpg', rating: 8.7 },
    { id: 's2', title: 'Dark', year: 2017, genre: ['Sci-Fi', 'Mystery'], type: 'series', description: 'Time travel mystery in Germany.', image: '/continue-dark.jpg', rating: 8.8 },
    { id: 's3', title: 'Severance', year: 2022, genre: ['Sci-Fi', 'Drama'], type: 'series', description: 'Work-life balance taken to extreme.', image: '/trending-severance.jpg', rating: 8.7 },
    { id: 's4', title: 'Rebel Moon', year: 2023, genre: ['Sci-Fi', 'Action'], type: 'movie', description: 'Epic space opera adventure.', image: '/new-rebel-moon.jpg', rating: 5.6 },
  ],
  drama: [
    { id: 'd1', title: 'The Crown', year: 2016, genre: ['Drama', 'History'], type: 'series', description: 'Queen Elizabeth II\'s reign.', image: '/continue-crown.jpg', rating: 8.7 },
    { id: 'd2', title: 'Breaking Bad', year: 2008, genre: ['Drama', 'Crime'], type: 'series', description: 'Chemistry teacher turned drug lord.', image: '/continue-breaking-bad.jpg', rating: 9.5 },
    { id: 'bm1', title: 'Dhadak 2', year: 2024, genre: ['Drama'], type: 'movie', description: 'A heartfelt story of love and resilience.', image: '/Top Movies/Dhadak 2.png', rating: 7.2 },
  { id: 'bm2', title: 'Dhurandhar', year: 2024, genre: ['Action', 'Thriller'], type: 'movie', description: 'A high-stakes mission turns personal.', image: '/Top Movies/Dhurandhar.png', rating: 7.8 },
    { id: 'd3', title: 'Oppenheimer', year: 2023, genre: ['Drama', 'Biography'], type: 'movie', description: 'The father of the atomic bomb.', image: '/trending-oppenheimer.jpg', rating: 8.6 },
    { id: 'd4', title: 'The Bear', year: 2022, genre: ['Drama', 'Comedy'], type: 'series', description: 'A chef\'s journey in Chicago.', image: '/trending-bear.jpg', rating: 8.4 },
    { id: 'th3', title: 'Anniversary', year: 2024, genre: ['Drama'], type: 'movie', description: 'A celebration turns suspenseful.', image: '/Top Hollywood/Anniversary.png', rating: 7.1 },
  ],
  thriller: [
    { id: 'th1', title: 'Money Heist', year: 2017, genre: ['Thriller', 'Crime'], type: 'series', description: 'The perfect robbery.', image: '/hero-money-heist.jpg', rating: 8.2 },
    { id: 'th2', title: 'Ozark', year: 2017, genre: ['Thriller', 'Crime'], type: 'series', description: 'Money laundering in the Ozarks.', image: '/continue-ozark.jpg', rating: 8.5 },
    { id: 'th3', title: 'Mindhunter', year: 2017, genre: ['Thriller', 'Crime'], type: 'series', description: 'Inside the criminal mind.', image: '/continue-mindhunter.jpg', rating: 8.6 },
    { id: 'th4', title: 'Saltburn', year: 2023, genre: ['Thriller', 'Drama'], type: 'movie', description: 'Obsession at a British estate.', image: '/new-saltburn.jpg', rating: 7.1 },
  ],
  horror: [
    { id: 'h1', title: 'The Last of Us', year: 2023, genre: ['Horror', 'Drama'], type: 'series', description: 'Post-apocalyptic survival.', image: '/trending-last-of-us.jpg', rating: 8.7 },
    { id: 'h2', title: 'Bird Box', year: 2018, genre: ['Horror', 'Thriller'], type: 'movie', description: 'Don\'t open your eyes.', image: '/top10-bird-box.jpg', rating: 6.6 },
    { id: 'h3', title: 'Stranger Things', year: 2016, genre: ['Horror', 'Sci-Fi'], type: 'series', description: 'The Upside Down awaits.', image: '/hero-stranger-things.jpg', rating: 8.7 },
  ],
  comedy: [
    { id: 'c1', title: 'The Bear', year: 2022, genre: ['Comedy', 'Drama'], type: 'series', description: 'Chaos in the kitchen.', image: '/trending-bear.jpg', rating: 8.4 },
    { id: 'c2', title: 'Don\'t Look Up', year: 2021, genre: ['Comedy', 'Satire'], type: 'movie', description: 'A comet is coming.', image: '/top10-dont-look-up.jpg', rating: 7.2 },
    { id: 'c3', title: 'The White Lotus', year: 2021, genre: ['Comedy', 'Drama'], type: 'series', description: 'Vacation gone wrong.', image: '/trending-white-lotus.jpg', rating: 7.9 },
    { id: 'c4', title: 'Wednesday', year: 2022, genre: ['Comedy', 'Fantasy'], type: 'series', description: 'Wednesday Addams at Nevermore.', image: '/top10-wednesday.jpg', rating: 8.1 },
  ]
};
